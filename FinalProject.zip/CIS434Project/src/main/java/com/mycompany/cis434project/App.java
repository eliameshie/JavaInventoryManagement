package com.mycompany.cis434project;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class App extends Application {

    private final List<ProjectItems> items = new ArrayList<>();
    private final List<ProjectItems> originalItems = new ArrayList<>();
    private final ListView<ProjectItems> listView = new ListView<>();
    private Stage primaryStage;

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage;
        showLogin();
    }

    private void showLogin() {
        GridPane loginPane = new GridPane();
        loginPane.setAlignment(Pos.CENTER);
        loginPane.setHgap(10);
        loginPane.setVgap(10);

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        Button loginButton = new Button("Login");

        loginButton.setOnAction(e -> {
            if (validateCredentials(usernameField.getText(), passwordField.getText())) {
                showMainView();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid username or password", ButtonType.OK);
                alert.showAndWait();
            }
        });

        loginPane.add(new Label("Username:"), 0, 0);
        loginPane.add(usernameField, 1, 0);
        loginPane.add(new Label("Password:"), 0, 1);
        loginPane.add(passwordField, 1, 1);
        loginPane.add(loginButton, 1, 2);

        Scene scene = new Scene(loginPane, 300, 200);
        primaryStage.setTitle("Login");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private boolean validateCredentials(String username, String password) {
        return username.equals("admin") && password.equals("password");
    }

    private void showMainView() {
        GridPane grid = new GridPane();
        grid.setVgap(10);
        grid.setHgap(10);

        TextField nameField = new TextField();
        nameField.setPromptText("Enter the item name:");
        TextField quantityField = new TextField();
        quantityField.setPromptText("Enter the number of items:");
        TextField priceField = new TextField();
        priceField.setPromptText("Enter the price per item:");

        Button addButton = createButtonWithTooltip("Add", "Add a new item");
        Button deleteButton = createButtonWithTooltip("Delete", "Delete the selected item");
        Button saveButton = createButtonWithTooltip("Save Log", "Save the inventory to a file");
        Button loadButton = createButtonWithTooltip("Load Log", "Load the inventory from a file");
        Button sortPriceAscButton = createButtonWithTooltip("Sort by Price Asc", "Sort items by price in ascending order");
        Button sortPriceDescButton = createButtonWithTooltip("Sort by Price Desc", "Sort items by price in descending order");
        Button sortTotalPriceAscButton = createButtonWithTooltip("Sort by Total Price Asc", "Sort items by total price in ascending order");
        Button sortTotalPriceDescButton = createButtonWithTooltip("Sort by Total Price Desc", "Sort items by total price in descending order");
        Button returnDefaultButton = createButtonWithTooltip("Return to Default", "Return the list to the original order");
        Button logoutButton = new Button("Logout");

        logoutButton.setOnAction(e -> {
            Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to logout? Make sure all data is saved.", ButtonType.YES, ButtonType.NO);
            confirmDialog.showAndWait().ifPresent(response -> {
                if (response == ButtonType.YES) {
                    showLogin();
                }
            });
        });

        grid.add(nameField, 0, 0, 2, 1);
        grid.add(quantityField, 2, 0);
        grid.add(priceField, 3, 0);
        grid.add(addButton, 0, 1);
        grid.add(deleteButton, 1, 1);
        grid.add(saveButton, 2, 1);
        grid.add(loadButton, 3, 1);
        grid.add(sortPriceAscButton, 0, 2);
        grid.add(sortPriceDescButton, 1, 2);
        grid.add(sortTotalPriceAscButton, 2, 2);
        grid.add(sortTotalPriceDescButton, 3, 2);
        grid.add(returnDefaultButton, 0, 3);
        grid.add(logoutButton, 1, 3);
        grid.add(listView, 0, 4, 4, 1); // ListView spans four columns.

        Scene scene = new Scene(grid, 400, 500);
        primaryStage.setTitle("Inventory Management System");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Button createButtonWithTooltip(String text, String tooltipText) {
        Button button = new Button(text);
        Tooltip tooltip = new Tooltip(tooltipText);
        tooltip.setShowDelay(javafx.util.Duration.millis(200)); // Delay to show tooltip
        button.setTooltip(tooltip);
        return button;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
