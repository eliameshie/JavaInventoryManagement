package com.mycompany.cis434project;

/**
 * Represents an item in the project inventory.
 */
public class ProjectItems implements Item {
    private String name;
    private int quantity;
    private double price;
    private double totalPrice;

    public ProjectItems(String name, int quantity, double price, double totalPrice) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
        this.totalPrice = totalPrice;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getQuanity() {
        return quantity;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public double getTotalPrice() {
        return totalPrice;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void setQuanity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    @Override
    public String toString() {
        return name + ", " + quantity + ", " + price + ", " + totalPrice;
    }

    public static ProjectItems fromString(String line) {
        String[] parts = line.split(",\\s*");  // This will split on a comma optionally followed by any whitespace
        if (parts.length != 4) {
            throw new IllegalArgumentException("Line format incorrect, expected format 'Name, Quantity, Price, Total Price': " + line);
        }
        String name = parts[0];
        int quantity;
        double price;
        double totalPrice;
        try {
            quantity = Integer.parseInt(parts[1]);
            price = Double.parseDouble(parts[2]);
            totalPrice = Double.parseDouble(parts[3]);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Quantity, price, or total price could not be parsed as a number.", e);
        }
        return new ProjectItems(name, quantity, price, totalPrice);
    }
}
