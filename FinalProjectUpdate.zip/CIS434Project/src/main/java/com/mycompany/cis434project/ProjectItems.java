package com.mycompany.cis434project;

public class ProjectItems implements Item {
    private String name;
    private int quantity;
    private double price;

    public ProjectItems(String name, int quantity, double price) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getQuantity() {
        return quantity;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public double getTotalPrice() {
        return quantity * price;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public void setPrice(double price) {
        this.price = price;
    }
    

    @Override
    public String toString() {
        return name + " - Qty: " + quantity + " - Price: $" + price + " - Total: $" + getTotalPrice();
    }
}
