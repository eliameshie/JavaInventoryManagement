package com.mycompany.cis434project;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class App extends Application {

    private final List<ProjectItems> items = new ArrayList<>();
    private final ListView<ProjectItems> listView = new ListView<>();
    private Stage primaryStage;

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage;
        showLogin();
    }

    private void showLogin() {
        GridPane loginPane = new GridPane();
        loginPane.setAlignment(Pos.CENTER);
        loginPane.setHgap(10);
        loginPane.setVgap(10);

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        Button loginButton = new Button("Login");

        // Add New User Button
        Button addNewUserButton = new Button("Add New User");
        addNewUserButton.setOnAction(e -> {
            if (hasSpecialPermission(usernameField.getText(), passwordField.getText())) {
                showNewUserDialog();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "You don't have permission to add a new user.");
                alert.showAndWait();
            }
        });

        loginButton.setOnAction(e -> {
            if (validateCredentials(usernameField.getText(), passwordField.getText())) {
                showMainView();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid username or password", ButtonType.OK);
                alert.showAndWait();
            }
        });

        loginPane.add(new Label("Username:"), 0, 0);
        loginPane.add(usernameField, 1, 0);
        loginPane.add(new Label("Password:"), 0, 1);
        loginPane.add(passwordField, 1, 1);
        loginPane.add(loginButton, 1, 2);
        loginPane.add(addNewUserButton, 0, 2);

        Scene scene = new Scene(loginPane, 300, 200);
        primaryStage.setTitle("Login");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void showNewUserDialog() {
        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Add New User");
        dialog.setHeaderText("Enter new user details:");

        ButtonType addButton = new ButtonType("Add", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(addButton, ButtonType.CANCEL);

        TextField newUsernameField = new TextField();
        newUsernameField.setPromptText("New Username");
        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPromptText("New Password");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("New Username:"), 0, 0);
        grid.add(newUsernameField, 1, 0);
        grid.add(new Label("New Password:"), 0, 1);
        grid.add(newPasswordField, 1, 1);
        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == addButton) {
                String username = newUsernameField.getText();
                String password = newPasswordField.getText();
                addUserCredentials(username, password);
                return username + "," + password;
            }
            return null;
        });

        dialog.showAndWait();
    }

    private void addUserCredentials(String username, String password) {
        File file = new File("users.txt");
        try (PrintWriter out = new PrintWriter(new FileWriter(file, true))) {
            out.println(username + "," + password);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean validateCredentials(String username, String password) {
        File file = new File("users.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] credentials = line.split(",");
                if (credentials[0].equals(username) && credentials[1].equals(password)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean hasSpecialPermission(String username, String password) {
        // Implement actual permission checking logic here
        return true; // For demonstration, assume all users have special permission
    }

    private void showMainView() {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setVgap(10);
        grid.setHgap(10);

        TextField nameField = new TextField();
        nameField.setPromptText("Enter the item name:");
        TextField quantityField = new TextField();
        quantityField.setPromptText("Enter the number of items:");
        TextField priceField = new TextField();
        priceField.setPromptText("Enter the price per item:");

        Button addButton = createButtonWithTooltip("Add", "Add a new item");
        Button deleteButton = createButtonWithTooltip("Delete", "Delete the selected item");
        Button saveButton = createButtonWithTooltip("Save Log", "Save the inventory to a file");
        Button loadButton = createButtonWithTooltip("Load Log", "Load the inventory from a file");
        Button sortPriceAscButton = createButtonWithTooltip("Sort by Price Asc", "Sort items by price in ascending order");
        Button sortPriceDescButton = createButtonWithTooltip("Sort by Price Desc", "Sort items by price in descending order");
        Button sortTotalPriceAscButton = createButtonWithTooltip("Sort by Total Price Asc", "Sort items by total price in ascending order");
        Button sortTotalPriceDescButton = createButtonWithTooltip("Sort by Total Price Desc", "Sort items by total price in descending order");
        Button returnDefaultButton = createButtonWithTooltip("Return to Default", "Return the list to the original order");
        Button logoutButton = new Button("Logout");
        Button totalPriceButton = createButtonWithTooltip("Show Total Price", "Display the total price of all items");

        addButton.setOnAction(e -> {
            try {
                String name = nameField.getText().trim();
                int quantity = Integer.parseInt(quantityField.getText().trim());
                double price = Double.parseDouble(priceField.getText().trim());
                boolean found = false;
                for (ProjectItems item : items) {
                    if (item.getName().equals(name) && item.getPrice() == price) {
                        item.setQuantity(item.getQuantity() + quantity);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    ProjectItems newItem = new ProjectItems(name, quantity, price);
                    items.add(newItem);
                    listView.getItems().add(newItem);
                }
                listView.refresh();  // Refresh ListView to show updated or new items
                nameField.clear();
                quantityField.clear();
                priceField.clear();
            } catch (NumberFormatException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid input. Please enter numeric values for quantity and price.");
                alert.showAndWait();
            }
        });

        deleteButton.setOnAction(e -> {
            ProjectItems selectedItem = listView.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                items.remove(selectedItem);
                listView.getItems().remove(selectedItem);
            }
        });

        saveButton.setOnAction(e -> {
            try (PrintWriter out = new PrintWriter("items.txt")) {
                for (ProjectItems item : items) {
                    out.println(item.getName() + "," + item.getQuantity() + "," + item.getPrice());
                }
            } catch (FileNotFoundException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to save file.");
                alert.showAndWait();
            }
        });

        loadButton.setOnAction(e -> loadItemsFromFile());

        sortPriceAscButton.setOnAction(e -> listView.getItems().sort(Comparator.comparingDouble(ProjectItems::getPrice)));
        sortPriceDescButton.setOnAction(e -> listView.getItems().sort(Comparator.comparingDouble(ProjectItems::getPrice).reversed()));
        sortTotalPriceAscButton.setOnAction(e -> listView.getItems().sort(Comparator.comparingDouble(ProjectItems::getTotalPrice)));
        sortTotalPriceDescButton.setOnAction(e -> listView.getItems().sort(Comparator.comparingDouble(ProjectItems::getTotalPrice).reversed()));

        returnDefaultButton.setOnAction(e -> {
            listView.setItems(null);
            listView.setItems(FXCollections.observableArrayList(items));  // Reset the ListView to the original list
        });

        logoutButton.setOnAction(e -> {
            Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to logout? Make sure all data is saved.", ButtonType.YES, ButtonType.NO);
            confirmDialog.showAndWait().ifPresent(response -> {
                if (response == ButtonType.YES) {
                    primaryStage.close();
                    showLogin();
                }
            });
        });

        grid.add(nameField, 0, 0, 2, 1);
        grid.add(quantityField, 2, 0);
        grid.add(priceField, 3, 0);
        grid.add(addButton, 0, 1);
        grid.add(deleteButton, 1, 1);
        grid.add(saveButton, 2, 1);
        grid.add(loadButton, 3, 1);
        grid.add(sortPriceAscButton, 0, 2);
        grid.add(sortPriceDescButton, 1, 2);
        grid.add(sortTotalPriceAscButton, 2, 2);
        grid.add(sortTotalPriceDescButton, 3, 2);
        grid.add(returnDefaultButton, 0, 3);
        grid.add(logoutButton, 1, 3);
        grid.add(listView, 0, 4, 4, 1); // ListView spans four columns.
        grid.add(totalPriceButton, 4, 0); // Total Price Button added here

        Scene scene = new Scene(grid, 400, 500);
        primaryStage.setTitle("Inventory Management System");
        primaryStage.setScene(scene);
        primaryStage.show();

        // Automatically load items from file
        loadItemsFromFile();
    }

    private void loadItemsFromFile() {
        File file = new File("items.txt");
        if (file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                items.clear();
                listView.getItems().clear();
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(",");
                    ProjectItems item = new ProjectItems(parts[0], Integer.parseInt(parts[1]), Double.parseDouble(parts[2]));
                    items.add(item);
                    listView.getItems().add(item);
                }
            } catch (IOException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to load file.");
                alert.showAndWait();
            }
        }
    }

    private double calculateTotalPrice() {
        double total = 0.0;
        for (ProjectItems item : items) {
            total += item.getPrice() * item.getQuantity();
        }
        return total;
    }

    private Button createButtonWithTooltip(String text, String tooltipText) {
        Button button = new Button(text);
        Tooltip tooltip = new Tooltip(tooltipText);
        tooltip.setShowDelay(javafx.util.Duration.millis(200)); // Delay to show tooltip
        button.setTooltip(tooltip);
        return button;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
