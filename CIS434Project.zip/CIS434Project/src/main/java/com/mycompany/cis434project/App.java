package com.mycompany.cis434project;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * JavaFX App for Inventory Management
 */
public class App extends Application {

    private final List<ProjectItems> items = new ArrayList<>();
    private final ListView<ProjectItems> listView = new ListView<>();

    @Override
    public void start(Stage stage) {
        TextField nameField = new TextField();
        nameField.setPromptText("Enter the item name:");

        TextField quantityField = new TextField();
        quantityField.setPromptText("Enter the number of items:");

        TextField priceField = new TextField();
        priceField.setPromptText("Enter the price per item:");

        Button addButton = new Button("Add");
        Button deleteButton = new Button("Delete");
        Button saveButton = new Button("Save Log");
        Button loadButton = new Button("Load Log");

        addButton.setOnAction(e -> {
            try {
                String name = nameField.getText();
                int quantity = Integer.parseInt(quantityField.getText());
                double price = Double.parseDouble(priceField.getText());
                addItem(name, quantity, price);
            } catch (NumberFormatException ex) {
                System.err.println("Invalid input. Please ensure quantity and price are numeric.");
            }
        });

        deleteButton.setOnAction(e -> deleteItem());
        saveButton.setOnAction(e -> saveItemsToFile());
        loadButton.setOnAction(e -> loadItemsFromFile("result.txt"));

        VBox root = new VBox(10, nameField, quantityField, priceField, addButton, deleteButton, saveButton, loadButton, listView);
        Scene scene = new Scene(root, 400, 500);
        stage.setTitle("Inventory Management System");
        stage.setScene(scene);
        stage.show();
    }

    private void addItem(String name, int quantity, double price) {
        boolean found = false;
        for (ProjectItems item : items) {
            if (item.getName().equals(name)) {
                item.setQuanity(item.getQuanity() + quantity);
                item.setPrice(item.getPrice() + price);
                found = true;
                break;
            }
        }
        if (!found) {
            items.add(new ProjectItems(name, quantity, price));
        }
        updateListView();
    }

    private void deleteItem() {
        ProjectItems selectedItem = listView.getSelectionModel().getSelectedItem();
        if (selectedItem != null) {
            items.remove(selectedItem);
            updateListView();
        }
    }

    private void saveItemsToFile() {
        File file = new File("result.txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (ProjectItems item : items) {
                writer.write(item.toString());
                writer.newLine();
            }
            System.out.println("Data saved to " + file.getAbsolutePath());
        } catch (IOException ex) {
            System.err.println("Error writing to text file: " + ex.getMessage());
        }
    }

    private void loadItemsFromFile(String filePath) {
        File file = new File(filePath);
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", "); // Assuming format "name, quantity, price"
                if (parts.length == 3) {
                    String name = parts[0];
                    int quantity = Integer.parseInt(parts[1]);
                    double price = Double.parseDouble(parts[2]);
                    items.add(new ProjectItems(name, quantity, price));
                }
            }
            updateListView();
        } catch (IOException ex) {
            System.err.println("Error reading the file: " + ex.getMessage());
        }
    }

    private void updateListView() {
        listView.getItems().clear();
        listView.getItems().addAll(items);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
