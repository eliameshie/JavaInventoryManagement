package com.mycompany.cis434project;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class StoreResults {

    public static void main(String[] args) {
        Result result = new Result("Test", 100);

        File file = new File("result.txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write(result.toString());
            System.out.println("Result written to " + file.getAbsolutePath());
        } catch (IOException ex) {
            System.err.println("Error writing to file: " + ex.getMessage());
        }
    }
}

class Result {
    public String name;
    public int score;

    public Result() {} // Default constructor

    public Result(String name, int score) {
        this.name = name;
        this.score = score;
    }

    @Override
    public String toString() {
        return "Result{name='" + name + "', score=" + score + "}";
    }
}
