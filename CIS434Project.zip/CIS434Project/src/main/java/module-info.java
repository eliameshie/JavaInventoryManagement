module com.mycompany.cis434project {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.cis434project to javafx.fxml;
    exports com.mycompany.cis434project;
    requires java.xml.bind;
    requires java.base;
}
